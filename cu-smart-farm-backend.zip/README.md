# cu-smart-farm-backend
Backend for CU smart farm 

# Current Progress
## Backend
 - can publish message to control device
 - can subscribe to topic and write data in to InfluxDB
 
