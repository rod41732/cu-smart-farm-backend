package common

var PossibleRelays = []string{"Relay1", "Relay2", "Relay3", "Relay4", "Relay5"}
var PossibleSensors = []string{"soil", "moisture", "humidity"}
