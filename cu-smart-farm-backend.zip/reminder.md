# reminder  
- because of some unknown reason: publish message should be JSON marshalled. also, QoS must be set to 0